var AFRAME = require("aframe");

var drawComponent = require("aframe-draw-component").component;
AFRAME.registerComponent("draw", drawComponent);

require("../index.js");
